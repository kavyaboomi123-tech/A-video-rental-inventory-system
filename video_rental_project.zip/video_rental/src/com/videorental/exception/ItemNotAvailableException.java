package com.videorental.exception;

public class ItemNotAvailableException extends Exception {
    public ItemNotAvailableException(String message) { super(message); }
}
