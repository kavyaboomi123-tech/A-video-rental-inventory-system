package com.videorental.dao;

import com.videorental.db.DatabaseManager;
import com.videorental.model.RentalTransaction;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RentalDAO {
    private final Connection conn;

    public RentalDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    public RentalTransaction insert(RentalTransaction rt) throws SQLException {
        String sql = """
            INSERT INTO rentals (customer_id, media_id, rented_on, due_date, returned_on, status, late_fee_charged)
            VALUES (?,?,?,?,?,?,?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, rt.getCustomerId());
            ps.setInt(2, rt.getMediaId());
            ps.setString(3, rt.getRentedOn().toString());
            ps.setString(4, rt.getDueDate().toString());
            ps.setString(5, rt.getReturnedOn() == null ? null : rt.getReturnedOn().toString());
            ps.setString(6, rt.getStatus().name());
            ps.setDouble(7, rt.getLateFeeCharged());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) rt.setId(keys.getInt(1));
            }
        }
        return rt;
    }

    public void markReturned(int rentalId, LocalDate returnedOn, double lateFee) throws SQLException {
        String sql = "UPDATE rentals SET returned_on = ?, status = 'RETURNED', late_fee_charged = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, returnedOn.toString());
            ps.setDouble(2, lateFee);
            ps.setInt(3, rentalId);
            ps.executeUpdate();
        }
    }

    public List<RentalTransaction> findActiveByMedia(int mediaId) throws SQLException {
        String sql = "SELECT * FROM rentals WHERE media_id = ? AND status = 'ACTIVE'";
        List<RentalTransaction> results = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, mediaId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) results.add(mapRow(rs));
            }
        }
        return results;
    }

    public List<RentalTransaction> findAll() throws SQLException {
        List<RentalTransaction> results = new ArrayList<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM rentals ORDER BY id")) {
            while (rs.next()) results.add(mapRow(rs));
        }
        return results;
    }

    public List<RentalTransaction> findByCustomer(int customerId) throws SQLException {
        String sql = "SELECT * FROM rentals WHERE customer_id = ? ORDER BY id";
        List<RentalTransaction> results = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) results.add(mapRow(rs));
            }
        }
        return results;
    }

    private RentalTransaction mapRow(ResultSet rs) throws SQLException {
        String returnedStr = rs.getString("returned_on");
        return new RentalTransaction(
                rs.getInt("id"),
                rs.getInt("customer_id"),
                rs.getInt("media_id"),
                LocalDate.parse(rs.getString("rented_on")),
                LocalDate.parse(rs.getString("due_date")),
                returnedStr == null ? null : LocalDate.parse(returnedStr),
                RentalTransaction.Status.valueOf(rs.getString("status")),
                rs.getDouble("late_fee_charged")
        );
    }
}
