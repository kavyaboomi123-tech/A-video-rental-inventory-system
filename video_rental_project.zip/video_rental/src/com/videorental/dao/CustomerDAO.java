package com.videorental.dao;

import com.videorental.db.DatabaseManager;
import com.videorental.exception.ItemNotFoundException;
import com.videorental.model.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    private final Connection conn;

    public CustomerDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    public Customer insert(Customer c) throws SQLException {
        String sql = "INSERT INTO customers (name, phone, email) VALUES (?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) c.setId(keys.getInt(1));
            }
        }
        return c;
    }

    public Customer findById(int id) throws SQLException, ItemNotFoundException {
        String sql = "SELECT * FROM customers WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Customer(rs.getInt("id"), rs.getString("name"),
                            rs.getString("phone"), rs.getString("email"));
                }
            }
        }
        throw new ItemNotFoundException("No customer found with id " + id);
    }

    public List<Customer> findAll() throws SQLException {
        List<Customer> results = new ArrayList<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM customers ORDER BY id")) {
            while (rs.next()) {
                results.add(new Customer(rs.getInt("id"), rs.getString("name"),
                        rs.getString("phone"), rs.getString("email")));
            }
        }
        return results;
    }
}
