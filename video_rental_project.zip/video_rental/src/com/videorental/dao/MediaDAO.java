package com.videorental.dao;

import com.videorental.db.DatabaseManager;
import com.videorental.exception.ItemNotFoundException;
import com.videorental.model.Media;
import com.videorental.model.Movie;
import com.videorental.model.VideoGame;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MediaDAO {
    private final Connection conn;

    public MediaDAO() {
        this.conn = DatabaseManager.getInstance().getConnection();
    }

    public Media insert(Media media) throws SQLException {
        String sql = """
            INSERT INTO media (media_type, title, genre, release_year, total_copies,
                                available_copies, director, duration_minutes, platform, age_rating)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, media.getMediaType());
            ps.setString(2, media.getTitle());
            ps.setString(3, media.getGenre());
            ps.setInt(4, media.getReleaseYear());
            ps.setInt(5, media.getTotalCopies());
            ps.setInt(6, media.getAvailableCopies());

            if (media instanceof Movie m) {
                ps.setString(7, m.getDirector());
                ps.setInt(8, m.getDurationMinutes());
                ps.setNull(9, Types.VARCHAR);
                ps.setNull(10, Types.VARCHAR);
            } else if (media instanceof VideoGame g) {
                ps.setNull(7, Types.VARCHAR);
                ps.setNull(8, Types.INTEGER);
                ps.setString(9, g.getPlatform());
                ps.setString(10, g.getAgeRating());
            }

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) media.setId(keys.getInt(1));
            }
        }
        return media;
    }

    public void updateAvailableCopies(int mediaId, int newAvailable) throws SQLException {
        String sql = "UPDATE media SET available_copies = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, newAvailable);
            ps.setInt(2, mediaId);
            ps.executeUpdate();
        }
    }

    public void delete(int mediaId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM media WHERE id = ?")) {
            ps.setInt(1, mediaId);
            ps.executeUpdate();
        }
    }

    public Media findById(int id) throws SQLException, ItemNotFoundException {
        String sql = "SELECT * FROM media WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        throw new ItemNotFoundException("No media found with id " + id);
    }

    public List<Media> findAll() throws SQLException {
        List<Media> results = new ArrayList<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM media ORDER BY id")) {
            while (rs.next()) results.add(mapRow(rs));
        }
        return results;
    }

    public List<Media> searchByTitle(String keyword) throws SQLException {
        List<Media> results = new ArrayList<>();
        String sql = "SELECT * FROM media WHERE LOWER(title) LIKE ? ORDER BY id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword.toLowerCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) results.add(mapRow(rs));
            }
        }
        return results;
    }

    /** Reconstructs the correct polymorphic subtype from a row. */
    private Media mapRow(ResultSet rs) throws SQLException {
        String type = rs.getString("media_type");
        int id = rs.getInt("id");
        String title = rs.getString("title");
        String genre = rs.getString("genre");
        int year = rs.getInt("release_year");
        int total = rs.getInt("total_copies");
        int avail = rs.getInt("available_copies");

        if ("MOVIE".equals(type)) {
            return new Movie(id, title, genre, year, total, avail,
                    rs.getString("director"), rs.getInt("duration_minutes"));
        } else {
            return new VideoGame(id, title, genre, year, total, avail,
                    rs.getString("platform"), rs.getString("age_rating"));
        }
    }
}
