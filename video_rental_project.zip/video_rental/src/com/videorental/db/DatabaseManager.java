package com.videorental.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Singleton responsible for the single SQLite connection and schema setup.
 */
public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:data/rental_store.db";
    private static DatabaseManager instance;
    private Connection connection;

    private DatabaseManager() {
        try {
            connection = DriverManager.getConnection(DB_URL);
            initSchema();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to connect to database: " + e.getMessage(), e);
        }
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) instance = new DatabaseManager();
        return instance;
    }

    public Connection getConnection() { return connection; }

    private void initSchema() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS media (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    media_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    genre TEXT,
                    release_year INTEGER,
                    total_copies INTEGER NOT NULL,
                    available_copies INTEGER NOT NULL,
                    director TEXT,
                    duration_minutes INTEGER,
                    platform TEXT,
                    age_rating TEXT
                )
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    phone TEXT,
                    email TEXT
                )
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS rentals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id INTEGER NOT NULL,
                    media_id INTEGER NOT NULL,
                    rented_on TEXT NOT NULL,
                    due_date TEXT NOT NULL,
                    returned_on TEXT,
                    status TEXT NOT NULL,
                    late_fee_charged REAL DEFAULT 0,
                    FOREIGN KEY (customer_id) REFERENCES customers(id),
                    FOREIGN KEY (media_id) REFERENCES media(id)
                )
            """);
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) { }
    }
}
