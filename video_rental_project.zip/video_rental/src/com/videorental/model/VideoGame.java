package com.videorental.model;

/**
 * Concrete Media type: VideoGame.
 * Demonstrates: Inheritance + Polymorphism (different rate/fee rules than Movie)
 */
public class VideoGame extends Media {
    private String platform; // e.g. PS5, Xbox, PC
    private String ageRating;
    private static final double BASE_RATE = 4.00;
    private static final double LATE_FEE_PER_DAY = 2.00;

    public VideoGame(int id, String title, String genre, int releaseYear,
                      int totalCopies, int availableCopies,
                      String platform, String ageRating) {
        super(id, title, genre, releaseYear, totalCopies, availableCopies);
        this.platform = platform;
        this.ageRating = ageRating;
    }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public String getAgeRating() { return ageRating; }
    public void setAgeRating(String ageRating) { this.ageRating = ageRating; }

    @Override
    public String getMediaType() { return "GAME"; }

    @Override
    public double getDailyRentalRate() { return BASE_RATE; }

    @Override
    public double calculateLateFee(int daysLate) {
        // Games incur a steeper, compounding-style fee after day 2
        if (daysLate <= 0) return 0;
        if (daysLate <= 2) return daysLate * LATE_FEE_PER_DAY;
        return (2 * LATE_FEE_PER_DAY) + (daysLate - 2) * (LATE_FEE_PER_DAY * 1.5);
    }

    @Override
    public String getRentalTerms() {
        return "Games (" + platform + "): 5-day rental, $" + LATE_FEE_PER_DAY +
                "/day late fee (steeper after day 2).";
    }
}
