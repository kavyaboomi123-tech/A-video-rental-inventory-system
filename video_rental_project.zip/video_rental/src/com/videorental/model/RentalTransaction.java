package com.videorental.model;

import java.time.LocalDate;

public class RentalTransaction {
    public enum Status { ACTIVE, RETURNED }

    private int id;
    private int customerId;
    private int mediaId;
    private LocalDate rentedOn;
    private LocalDate dueDate;
    private LocalDate returnedOn; // null while active
    private Status status;
    private double lateFeeCharged;

    public RentalTransaction(int id, int customerId, int mediaId,
                              LocalDate rentedOn, LocalDate dueDate,
                              LocalDate returnedOn, Status status, double lateFeeCharged) {
        this.id = id;
        this.customerId = customerId;
        this.mediaId = mediaId;
        this.rentedOn = rentedOn;
        this.dueDate = dueDate;
        this.returnedOn = returnedOn;
        this.status = status;
        this.lateFeeCharged = lateFeeCharged;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCustomerId() { return customerId; }
    public int getMediaId() { return mediaId; }

    public LocalDate getRentedOn() { return rentedOn; }
    public LocalDate getDueDate() { return dueDate; }

    public LocalDate getReturnedOn() { return returnedOn; }
    public void setReturnedOn(LocalDate returnedOn) { this.returnedOn = returnedOn; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public double getLateFeeCharged() { return lateFeeCharged; }
    public void setLateFeeCharged(double lateFeeCharged) { this.lateFeeCharged = lateFeeCharged; }

    @Override
    public String toString() {
        return String.format("[#%d] cust=%d media=%d rented=%s due=%s returned=%s status=%s lateFee=$%.2f",
                id, customerId, mediaId, rentedOn, dueDate,
                returnedOn == null ? "-" : returnedOn, status, lateFeeCharged);
    }
}
