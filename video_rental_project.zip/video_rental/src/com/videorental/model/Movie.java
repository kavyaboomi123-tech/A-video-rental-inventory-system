package com.videorental.model;

/**
 * Concrete Media type: Movie.
 * Demonstrates: Inheritance (extends Media) + Polymorphism (overrides abstract/interface methods)
 */
public class Movie extends Media {
    private String director;
    private int durationMinutes;
    private static final double BASE_RATE = 2.50;
    private static final double LATE_FEE_PER_DAY = 1.00;

    public Movie(int id, String title, String genre, int releaseYear,
                 int totalCopies, int availableCopies,
                 String director, int durationMinutes) {
        super(id, title, genre, releaseYear, totalCopies, availableCopies);
        this.director = director;
        this.durationMinutes = durationMinutes;
    }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    @Override
    public String getMediaType() { return "MOVIE"; }

    @Override
    public double getDailyRentalRate() { return BASE_RATE; }

    @Override
    public double calculateLateFee(int daysLate) {
        return daysLate <= 0 ? 0 : daysLate * LATE_FEE_PER_DAY;
    }

    @Override
    public String getRentalTerms() {
        return "Movies: 3-day rental, $" + LATE_FEE_PER_DAY + "/day late fee.";
    }
}
