package com.videorental.model;

/**
 * Abstract base class for all rentable media items.
 * Demonstrates: Abstraction + Encapsulation (private fields, public accessors)
 */
public abstract class Media implements Rentable {
    private int id;                 // 0 = not yet persisted
    private String title;
    private String genre;
    private int releaseYear;
    private int totalCopies;
    private int availableCopies;

    protected Media(int id, String title, String genre, int releaseYear,
                     int totalCopies, int availableCopies) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
    }

    // ---- Encapsulated accessors ----
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getReleaseYear() { return releaseYear; }
    public void setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }

    public int getTotalCopies() { return totalCopies; }
    public void setTotalCopies(int totalCopies) { this.totalCopies = totalCopies; }

    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) { this.availableCopies = availableCopies; }

    public boolean isAvailable() { return availableCopies > 0; }

    public void checkOut() {
        if (!isAvailable()) throw new IllegalStateException("No copies available for: " + title);
        availableCopies--;
    }

    public void checkIn() {
        if (availableCopies < totalCopies) availableCopies++;
    }

    /** Every subtype must describe what kind of media it is (polymorphism). */
    public abstract String getMediaType();

    /** Every subtype must define how it is displayed in listings (polymorphism). */
    @Override
    public String toString() {
        return String.format("[#%d] %-6s | %-25s | %-12s | %d | %d/%d avail | $%.2f/day",
                id, getMediaType(), title, genre, releaseYear, availableCopies, totalCopies,
                getDailyRentalRate());
    }
}
