package com.videorental.model;

/**
 * Abstraction: any media type that can be rented must implement this contract.
 */
public interface Rentable {
    double getDailyRentalRate();
    double calculateLateFee(int daysLate);
    String getRentalTerms();
}
