package com.videorental.service;

import com.videorental.dao.MediaDAO;
import com.videorental.exception.ItemNotFoundException;
import com.videorental.model.Media;

import java.sql.SQLException;
import java.util.List;

public class InventoryService {
    private final MediaDAO mediaDAO = new MediaDAO();

    public Media addMedia(Media media) throws SQLException {
        return mediaDAO.insert(media);
    }

    public void removeMedia(int mediaId) throws SQLException {
        mediaDAO.delete(mediaId);
    }

    public List<Media> listAll() throws SQLException {
        return mediaDAO.findAll();
    }

    public List<Media> search(String keyword) throws SQLException {
        return mediaDAO.searchByTitle(keyword);
    }

    public Media getById(int id) throws SQLException, ItemNotFoundException {
        return mediaDAO.findById(id);
    }

    public void persistAvailability(Media media) throws SQLException {
        mediaDAO.updateAvailableCopies(media.getId(), media.getAvailableCopies());
    }
}
