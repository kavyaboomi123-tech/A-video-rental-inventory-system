package com.videorental.service;

import com.videorental.dao.MediaDAO;
import com.videorental.dao.RentalDAO;
import com.videorental.exception.ItemNotAvailableException;
import com.videorental.exception.ItemNotFoundException;
import com.videorental.model.Media;
import com.videorental.model.Movie;
import com.videorental.model.RentalTransaction;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class RentalService {
    private final MediaDAO mediaDAO = new MediaDAO();
    private final RentalDAO rentalDAO = new RentalDAO();

    /** Rents an item out to a customer, enforcing availability rules. */
    public RentalTransaction rentItem(int customerId, int mediaId)
            throws SQLException, ItemNotFoundException, ItemNotAvailableException {

        Media media = mediaDAO.findById(mediaId);
        if (!media.isAvailable()) {
            throw new ItemNotAvailableException(
                    "'" + media.getTitle() + "' has no copies available right now.");
        }

        media.checkOut(); // polymorphic inventory decrement, defined once in Media
        mediaDAO.updateAvailableCopies(mediaId, media.getAvailableCopies());

        int rentalDays = (media instanceof Movie) ? 3 : 5; // differs by media type
        LocalDate today = LocalDate.now();
        RentalTransaction rt = new RentalTransaction(
                0, customerId, mediaId, today, today.plusDays(rentalDays),
                null, RentalTransaction.Status.ACTIVE, 0.0);

        return rentalDAO.insert(rt);
    }

    /** Returns an item, computing any late fee polymorphically via the media's own rules. */
    public double returnItem(int rentalId, int mediaId) throws SQLException, ItemNotFoundException {
        Media media = mediaDAO.findById(mediaId);

        List<RentalTransaction> active = rentalDAO.findActiveByMedia(mediaId);
        RentalTransaction rt = active.stream()
                .filter(r -> r.getId() == rentalId)
                .findFirst()
                .orElseThrow(() -> new ItemNotFoundException(
                        "No active rental #" + rentalId + " found for media #" + mediaId));

        LocalDate today = LocalDate.now();
        long daysLate = ChronoUnit.DAYS.between(rt.getDueDate(), today);
        double lateFee = media.calculateLateFee((int) daysLate); // polymorphic dispatch

        rentalDAO.markReturned(rentalId, today, lateFee);

        media.checkIn();
        mediaDAO.updateAvailableCopies(mediaId, media.getAvailableCopies());

        return lateFee;
    }

    public List<RentalTransaction> allRentals() throws SQLException {
        return rentalDAO.findAll();
    }

    public List<RentalTransaction> rentalsForCustomer(int customerId) throws SQLException {
        return rentalDAO.findByCustomer(customerId);
    }
}
