package com.videorental;

import com.videorental.dao.CustomerDAO;
import com.videorental.db.DatabaseManager;
import com.videorental.exception.ItemNotAvailableException;
import com.videorental.exception.ItemNotFoundException;
import com.videorental.model.*;
import com.videorental.service.InventoryService;
import com.videorental.service.RentalService;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final InventoryService inventoryService = new InventoryService();
    private static final RentalService rentalService = new RentalService();
    private static final CustomerDAO customerDAO = new CustomerDAO();

    public static void main(String[] args) {
        // Ensure DB + schema are ready before anything else runs
        DatabaseManager.getInstance();
        System.out.println("=== Video Rental Inventory System ===");

        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> addMedia();
                    case "2" -> listInventory();
                    case "3" -> searchMedia();
                    case "4" -> removeMedia();
                    case "5" -> addCustomer();
                    case "6" -> listCustomers();
                    case "7" -> rentItem();
                    case "8" -> returnItem();
                    case "9" -> viewAllRentals();
                    case "10" -> viewCustomerHistory();
                    case "0" -> {
                        running = false;
                        System.out.println("Goodbye!");
                    }
                    default -> System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            } catch (ItemNotFoundException | ItemNotAvailableException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
        DatabaseManager.getInstance().close();
    }

    private static void printMenu() {
        System.out.println("""
                
                ---------------------------------------------
                1.  Add Media (Movie / Video Game)
                2.  List All Inventory
                3.  Search Media by Title
                4.  Remove Media
                5.  Add Customer
                6.  List Customers
                7.  Rent Item
                8.  Return Item
                9.  View All Rental Transactions
                10. View Rental History for a Customer
                0.  Exit
                ---------------------------------------------
                Choose an option: """);
    }

    private static void addMedia() throws SQLException {
        System.out.print("Type (1=Movie, 2=Game): ");
        String type = sc.nextLine().trim();
        System.out.print("Title: ");
        String title = sc.nextLine().trim();
        System.out.print("Genre: ");
        String genre = sc.nextLine().trim();
        System.out.print("Release Year: ");
        int year = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Total Copies: ");
        int total = Integer.parseInt(sc.nextLine().trim());

        Media media;
        if (type.equals("1")) {
            System.out.print("Director: ");
            String director = sc.nextLine().trim();
            System.out.print("Duration (minutes): ");
            int duration = Integer.parseInt(sc.nextLine().trim());
            media = new Movie(0, title, genre, year, total, total, director, duration);
        } else {
            System.out.print("Platform (e.g. PS5/Xbox/PC): ");
            String platform = sc.nextLine().trim();
            System.out.print("Age Rating: ");
            String rating = sc.nextLine().trim();
            media = new VideoGame(0, title, genre, year, total, total, platform, rating);
        }

        Media saved = inventoryService.addMedia(media);
        System.out.println("Added: " + saved);
    }

    private static void listInventory() throws SQLException {
        List<Media> all = inventoryService.listAll();
        if (all.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }
        all.forEach(System.out::println);
    }

    private static void searchMedia() throws SQLException {
        System.out.print("Search keyword: ");
        String kw = sc.nextLine().trim();
        List<Media> results = inventoryService.search(kw);
        if (results.isEmpty()) System.out.println("No matches found.");
        else results.forEach(System.out::println);
    }

    private static void removeMedia() throws SQLException {
        System.out.print("Media ID to remove: ");
        int id = Integer.parseInt(sc.nextLine().trim());
        inventoryService.removeMedia(id);
        System.out.println("Removed media #" + id);
    }

    private static void addCustomer() throws SQLException {
        System.out.print("Name: ");
        String name = sc.nextLine().trim();
        System.out.print("Phone: ");
        String phone = sc.nextLine().trim();
        System.out.print("Email: ");
        String email = sc.nextLine().trim();
        Customer c = customerDAO.insert(new Customer(0, name, phone, email));
        System.out.println("Added: " + c);
    }

    private static void listCustomers() throws SQLException {
        List<Customer> all = customerDAO.findAll();
        if (all.isEmpty()) System.out.println("No customers yet.");
        else all.forEach(System.out::println);
    }

    private static void rentItem() throws SQLException, ItemNotFoundException, ItemNotAvailableException {
        System.out.print("Customer ID: ");
        int custId = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Media ID: ");
        int mediaId = Integer.parseInt(sc.nextLine().trim());

        // Validate customer exists (throws if not)
        customerDAO.findById(custId);

        RentalTransaction rt = rentalService.rentItem(custId, mediaId);
        System.out.println("Rented! " + rt);
        Media m = inventoryService.getById(mediaId);
        System.out.println("Terms: " + m.getRentalTerms());
    }

    private static void returnItem() throws SQLException, ItemNotFoundException {
        System.out.print("Rental Transaction ID: ");
        int rentalId = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Media ID: ");
        int mediaId = Integer.parseInt(sc.nextLine().trim());

        double lateFee = rentalService.returnItem(rentalId, mediaId);
        if (lateFee > 0) {
            System.out.printf("Returned late. Late fee charged: $%.2f%n", lateFee);
        } else {
            System.out.println("Returned on time. No late fee.");
        }
    }

    private static void viewAllRentals() throws SQLException {
        List<RentalTransaction> all = rentalService.allRentals();
        if (all.isEmpty()) System.out.println("No rental transactions yet.");
        else all.forEach(System.out::println);
    }

    private static void viewCustomerHistory() throws SQLException, ItemNotFoundException {
        System.out.print("Customer ID: ");
        int custId = Integer.parseInt(sc.nextLine().trim());
        customerDAO.findById(custId); // validates existence
        List<RentalTransaction> history = rentalService.rentalsForCustomer(custId);
        if (history.isEmpty()) System.out.println("No rental history for this customer.");
        else history.forEach(System.out::println);
    }
}
