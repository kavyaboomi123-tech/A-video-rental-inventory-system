# Video Rental Inventory System

A Java command-line application for managing a video rental store: inventory
(movies & video games), customers, and rental transactions — backed by a real
SQLite database.

## OOP Concepts Demonstrated

| Concept | Where |
|---|---|
| **Abstraction** | `Media` is an abstract class; `Rentable` is an interface defining the rental contract (rate, late fee, terms). |
| **Encapsulation** | All model fields are `private` with controlled getters/setters (e.g. `Media.checkOut()` / `checkIn()` guard the available-copies invariant instead of letting callers mutate it directly). |
| **Inheritance** | `Movie` and `VideoGame` both extend `Media`, inheriting shared fields/behavior (id, title, availability tracking) while adding their own (director/duration vs platform/age rating). |
| **Polymorphism** | `getMediaType()`, `getDailyRentalRate()`, `calculateLateFee()`, and `getRentalTerms()` are overridden differently by `Movie` and `VideoGame`. `RentalService` calls these through the `Media` reference without knowing the concrete subtype — e.g. games have a steeper late-fee curve after day 2. |
| **Layered design** | `model` (domain objects) → `dao` (JDBC persistence) → `service` (business rules) → `Main` (CLI presentation). Each layer only talks to the one below it. |
| **Custom exceptions** | `ItemNotFoundException`, `ItemNotAvailableException` for domain-specific, checked error handling instead of generic exceptions. |

## Project Structure

```
video_rental/
├── src/com/videorental/
│   ├── model/        Media (abstract), Movie, VideoGame, Customer, RentalTransaction, Rentable
│   ├── dao/           MediaDAO, CustomerDAO, RentalDAO (JDBC/SQL layer)
│   ├── db/            DatabaseManager (connection + schema, singleton)
│   ├── service/       InventoryService, RentalService (business logic)
│   ├── exception/     ItemNotFoundException, ItemNotAvailableException
│   └── Main.java      CLI menu entry point
├── lib/
│   ├── sqlite-jdbc.jar    SQLite JDBC driver (Xerial)
│   └── slf4j-api.jar      SLF4J API + no-op provider (required by sqlite-jdbc)
├── data/                  SQLite database file is created here at runtime
└── README.md
```

## Requirements

- Java 17+ (developed/tested on Java 21)
- No external database server needed — SQLite runs embedded in a local file
  (`data/rental_store.db`, created automatically on first run).

## Build

From the `video_rental/` directory:

```bash
mkdir -p out
find src -name "*.java" > sources.txt
javac -cp "lib/sqlite-jdbc.jar:lib/slf4j-api.jar" -d out @sources.txt
```

On Windows, use `;` instead of `:` as the classpath separator.

## Run

```bash
java -cp "out:lib/sqlite-jdbc.jar:lib/slf4j-api.jar" com.videorental.Main
```

(Windows: `java -cp "out;lib/sqlite-jdbc.jar;lib/slf4j-api.jar" com.videorental.Main`)

## Using the App

The CLI presents a numbered menu:

```
1.  Add Media (Movie / Video Game)
2.  List All Inventory
3.  Search Media by Title
4.  Remove Media
5.  Add Customer
6.  List Customers
7.  Rent Item
8.  Return Item
9.  View All Rental Transactions
10. View Rental History for a Customer
0.  Exit
```

Typical flow:
1. Add a few movies/games (option 1).
2. Add a customer (option 5).
3. Rent an item to that customer by ID (option 7) — this decrements
   available copies and creates a rental record with a due date
   (3 days for movies, 5 days for games).
4. Return it later (option 8) — the app computes any late fee using
   each media type's own rule (`calculateLateFee`), and restores the copy
   to inventory.
5. Check option 9 or 10 to review transaction history.

All data persists in `data/rental_store.db` between runs.

## Business Rules

- **Movies**: $2.50/day rental, 3-day rental period, $1.00/day flat late fee.
- **Video Games**: $4.00/day rental, 5-day rental period, $2.00/day late fee
  for the first 2 late days, then $3.00/day after that.
- An item can't be rented if `available_copies == 0`
  (`ItemNotAvailableException`).
- Looking up a non-existent media/customer ID throws
  `ItemNotFoundException`, caught and reported cleanly by the CLI instead of
  crashing.
